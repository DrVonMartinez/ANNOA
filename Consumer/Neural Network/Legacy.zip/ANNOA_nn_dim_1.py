import glob
import os

import numpy as np
import pandas as pd
import tensorflow as tf
from keras.layers import Dense, Input
from keras.metrics import mae
from keras.models import Sequential
from Utilities.Constants import DIMENSION_SET, SIZE_SET, NUM_HIDDEN_LAYERS, HIDDEN_NEURONS, NUM_EPOCHS, OPTIMIZER_SET, METRIC_SET

physical_devices = tf.config.list_physical_devices('GPU')
tf.config.experimental.set_memory_growth(physical_devices[0], True)


class Ozturk:
    def __init__(self, size=200, dimension=1, hidden_neurons=250, epochs=100, full_classes=False, full_data=False):
        """
        loss function selection following suggestions from https://medium.com/data-science-group-iitr/loss-functions-and-optimization-algorithms-demystified-bb92daff331c
        Optimizer selection following suggestions from https://algorithmia.com/blog/introduction-to-optimizers
        :param size:
        :param dimension:
        :param hidden_neurons:
        :param epochs:
        :param full_classes:
        :param full_data:
        """
        print('Ozturk Algorithm',
              'Epochs: ' + str(epochs),
              'Neurons: ' + str(hidden_neurons),
              'Size: ' + str(size),
              'Dimension: ' + str(dimension),
              'Full Class Set: ' + str(bool(full_classes)),
              'Full Data Set: ' + str(bool(full_data)),
              sep='\n')
        self.__size = int(size)
        self.__dim = int(dimension)
        self.__sample_size = 0

        # Load Training Data
        self.__theta: tf.Tensor = tf.zeros((self.__size,))
        self.__class_set = []
        self.__distribution_names = []
        self.__full_data = full_data
        self.__full_classes = full_classes

        # Setting up ANNOA
        self.__train_ratio = 0.80
        self.__validation_ratio = 0.20
        self.__batch_size = 64
        self.__epochs = epochs
        self.__num_hidden_layers = 0
        self.__optimizer = 'None'
        self.__hidden_neurons = hidden_neurons
        self.__shapes = {}
        self.__model = None

        self.__dtype = np.float32
        self.__history = {}
        self.__training = {}
        self.__title = 'No Title Set'

    def define_network(self, num_hidden_layers, optimizer):
        self.__num_hidden_layers = num_hidden_layers
        self.__optimizer = optimizer
        self.__model = Sequential(layers=[Input(shape=self.__shapes['input'], name='UV Input')])
        for i in range(self.__num_hidden_layers):
            self.__model.add(Dense(self.__hidden_neurons, activation='relu', name='ANNOA_Hidden_' + str(i + 1)))
        self.__model.add(Dense(self.__shapes['output'], activation='softmax', name='Output'))
        self.__model.compile(optimizer=self.__optimizer, loss='categorical_crossentropy', metrics=[mae, 'accuracy'])
        print(self.__distribution_names)
        print(self.__model.summary())
        self.__title = self.__set_title()

    def __define_shape(self, ):
        if self.__full_data:
            self.__shapes = {'input': ((self.__size + 1) * 2,), 'hidden': (self.__hidden_neurons,)}
        else:
            self.__shapes = {'input': (2,), 'hidden': (self.__hidden_neurons,)}
        self.__shapes['output'] = len(self.__distribution_names)

    def size(self):
        return self.__size

    def dim(self):
        return self.__dim

    def __str__(self):
        return 'gen_Ozturk_[' + str(self.__size) + ']_[' + str(self.__full_classes) + ']' + self.__full_data_label().replace(' ', '_') + '_' + str(self.__num_hidden_layers)

    def train(self):
        assert len(self.__training.keys()) > 0
        self.__history = self.__model.fit(self.__training['input'], self.__training['output'], self.__batch_size, self.__epochs, validation_split=self.__validation_ratio)

    def prepare_training_data(self):
        cwd = self.__change_cwd_data()
        distribution_files = []
        for file in list(glob.glob('Compressed * Data Set ' + str(self.__size) + '.gz_dist_' + str(self.__size))):
            title = file.split('\\')[-1]
            dist = title.split(' ')[1:-3]
            if self.__full_classes:
                self.__distribution_names.append(' '.join(dist))
                distribution_files.append(file)
            elif all(map(lambda x: x == dist[0], dist)):
                self.__distribution_names.append(' '.join(dist))
                distribution_files.append(file)
        print(self.__distribution_names)
        batch_columns = []
        if self.__full_data:
            for i in range(self.__size + 1):
                batch_columns.append('U' + str(i))
                batch_columns.append('V' + str(i))
        else:
            batch_columns += ['U', 'V']
        batch_input_list = []
        batch_output_list = []
        for file in distribution_files:
            batch_df = pd.read_csv(file, compression='gzip', dtype=self.__dtype).fillna(value=0)
            batch_input_temp = batch_df[batch_columns]
            batch_output_temp = batch_df[self.__distribution_names]
            batch_input_list.append(batch_input_temp)
            batch_output_list.append(batch_output_temp)
        pd_batch_input = pd.concat(batch_input_list)
        pd_batch_output = pd.concat(batch_output_list)
        seed = 9
        np.random.seed(seed=seed)
        reindex = np.random.permutation(pd_batch_input.shape[0])
        batch_input = pd_batch_input.to_numpy()[reindex]
        batch_output = pd_batch_output.to_numpy()[reindex]

        print(batch_input.shape)
        print(batch_output.shape)
        self.__revert(cwd)
        self.__training = {'input': batch_input, 'output': batch_output}
        self.__define_shape()

    def store(self):
        history_keys = ['loss', 'mean_absolute_error', 'accuracy']
        cwd = self.__change_cwd_results()
        history_df = pd.DataFrame(columns=METRIC_SET)
        for key, col in zip(history_keys, METRIC_SET):
            history_df[col] = self.__history.history[key]
        history_df.to_csv(self.__title + '.csv', index=False)
        self.__revert(cwd)

    def __revert(self, cwd):
        os.chdir(cwd)
        return self.__size

    def __change_cwd_data(self):
        cwd = os.getcwd()
        os.chdir('..\\..\\Data\\')
        cwd_dir = os.getcwd()
        new_dir = '\\dim ' + str(self.__dim)
        os.chdir(cwd_dir + new_dir)
        return cwd

    def __change_cwd_results(self):
        cwd = os.getcwd()
        if self.__full_data:
            data = 'All Data'
        else:
            data = 'Partial Data'
        if self.__full_classes:
            classes = 'Full Classes'
        else:
            classes = 'Limited Classes'
        new_dir = '\\' + data + '\\' + classes + '\\'
        os.chdir('..\\..\\Results\\')
        cwd_dir = os.getcwd()
        os.chdir(cwd_dir + new_dir)
        return cwd

    def __set_title(self):
        return 'Dim {}, Hidden Layer {}, Size {}, {}'.format(self.__dim, self.__num_hidden_layers, self.__size, self.__optimizer)


def main():
    assert (__name__ == "__main__"), "Method not intended to be called if this isn't the main file"
    # sizes = [10, 25, 50, 75, 80, 100, 125, 150, 200, 500, 1000]
    import sys
    # full_data, full_classes = list(map(lambda x: x == 'True', sys.argv[1:3]))
    # print(full_data, full_classes)
    for full_data in [True, False]:
        for full_classes in [True]:
            for dimension in [1]:
                for size in SIZE_SET:
                    training_model = Ozturk(size=size,
                                            dimension=dimension,
                                            hidden_neurons=HIDDEN_NEURONS,
                                            epochs=NUM_EPOCHS,
                                            full_classes=full_classes,
                                            full_data=full_data)
                    training_model.prepare_training_data()
                    for num_hidden_layers in NUM_HIDDEN_LAYERS:
                        for optimizer in OPTIMIZER_SET[1:2]:
                            training_model.define_network(num_hidden_layers, optimizer)
                            training_model.train()
                            training_model.store()


if __name__ == "__main__":
    '''
    Optimized for training size ANNOA
    '''
    main()
