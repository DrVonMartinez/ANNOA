#  -*- coding: utf-8 -*-
"""
@author: Benjamin
The Goal is to have Ozturk's Algorithm:
    Utilize Data Mining:
        For Classification
        For Cluster Detection
        For Association Learning

"""
__spec__ = None

import os
# Artificial Neural Network Ozturk
import warnings

import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_probability as tfp
from scipy.stats import norm, uniform, expon, cauchy, laplace, logistic, rayleigh
from tensorflow import math, linalg, raw_ops

from Distribution.Distribution_tensor import Distribution

warnings.filterwarnings("ignore", category=FutureWarning)


class OzturkTrain:
    def __init__(self, monte_carlo=2000, size=200, dimension=1):
        """
        loss function selection following suggestions from https://medium.com/data-science-group-iitr/loss-functions-and-optimization-algorithms-demystified-bb92daff331c
        Optimizer selection following suggestions from https://algorithmia.com/blog/introduction-to-optimizers
        :param monte_carlo:
        :param size:
        :param dimension:
        """
        if __name__ == "__main__":
            print('Ozturk Algorithm',
                  'Monte Carlo: ' + str(monte_carlo),
                  "Dimension: " + str(dimension),
                  'Size: ' + str(size),
                  flush=True,
                  sep='\n')
        self.__monte_carlo = int(monte_carlo)
        self.__size = size
        self.__dim = int(dimension)
        self.__theta: tf.Tensor
        self.__dtype = np.float32
        self.__reference_set()
        self.__num_classes = None
        self.__class_set = []
        if self.__monte_carlo < 1000:
            warnings.warn('Warning! Small Number of Monte Carlo Simulations')

    def train(self, distributions):
        """
        :param distributions:
        :return:
        """
        import itertools
        for index in itertools.product(range(len(distributions)), repeat=self.__dim):
            dist = Distribution(distributions[index[0]])
            for i in range(1, len(index)):
                dist += Distribution(distributions[index[i]])
            assert dist.dimension() == self.__dim, 'Dimension mismatch. Dimension should be ' + str(self.__dim) + ' but is ' + str(dist.dimension())
            self.__class_set.append(dist)
        cwd = self.__change_cwd()
        distribution_df = pd.DataFrame(dtype=self.__dtype)
        for distribution_set in self.__class_set:
            distribution_df = self.__oa_hidden_seq(distribution_set, distribution_df)
        self.__store_seq(distribution_df)
        self.__revert(cwd)

    def train_single_distribution(self, distribution_set: list):
        distribution_sequence = Distribution(distribution_set[0])
        for i in range(1, self.__dim):
            distribution_sequence += Distribution(distribution_set[i])
        cwd = self.__change_cwd()
        self.__oa_hidden_single(distribution_sequence)
        self.__revert(cwd)

    def __oa_hidden(self, distribution_sequence):
        print(str(distribution_sequence), flush=True)
        train_ozturk = self.__beta_reduction(distribution_sequence)
        train_ozturk = tf.sort(train_ozturk, axis=1, name='sorted ozturk')
        mean_ozturk = raw_ops.Mean(input=train_ozturk, axis=1, keep_dims=True, name='mean ozturk')
        var_ozturk = tfp.stats.stddev(train_ozturk, sample_axis=1, keepdims=True, name='variance ozturk')
        detrended = (train_ozturk - mean_ozturk) / var_ozturk
        u, v = self.__ozturk_function(detrended)
        columns_full = ['U', 'V']
        for i in range(self.__size + 1):
            columns_full.append('U' + str(i))
            columns_full.append('V' + str(i))
        distribution_set = [str(distribution_sequence)]
        for dist in str(distribution_sequence).split(' '):
            if dist not in distribution_set:
                distribution_set.append(dist)
        columns_full += distribution_set
        return u, v, columns_full

    def __oa_hidden_single(self, distribution_sequence):
        u, v, columns_full = self.__oa_hidden(distribution_sequence)

        oa_producer_df = pd.DataFrame(columns=columns_full, dtype=self.__dtype)
        oa_producer_df['U'] = u[:, -1]
        oa_producer_df['V'] = v[:, -1]
        ones = np.ones((self.__monte_carlo, 1))
        for values in [str(distribution_sequence)]:
            oa_producer_df[values] = ones

        for i in range(self.__size + 1):
            oa_producer_df['U' + str(i)] = u[:, i]
            oa_producer_df['V' + str(i)] = v[:, i]

        try:
            existing_df = pd.read_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', dtype=self.__dtype)
            existing_df = existing_df.append(oa_producer_df)
            existing_df = self.__adjust_columns(existing_df)
            existing_df.to_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', index=False)
        except FileNotFoundError:
            oa_producer_df.to_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', index=False)

    def __oa_hidden_seq(self, distribution_sequence, existing_df):
        u, v, columns_full = self.__oa_hidden(distribution_sequence)
        oa_producer_df = pd.DataFrame(columns=columns_full, dtype=self.__dtype)
        oa_producer_df['U'] = u[:, -1]
        oa_producer_df['V'] = v[:, -1]
        ones = np.ones((self.__monte_carlo, 1))
        for values in [str(distribution_sequence)]:
            oa_producer_df[values] = ones

        for i in range(self.__size + 1):
            oa_producer_df['U' + str(i)] = u[:, i]
            oa_producer_df['V' + str(i)] = v[:, i]
        return existing_df.append(oa_producer_df)

    def __store_seq(self, oa_producer_df):
        try:
            existing_df = pd.read_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', dtype=self.__dtype)
            existing_df = existing_df.append(oa_producer_df)
            existing_df = self.__adjust_columns(existing_df)
            existing_df.to_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', index=False)
        except FileNotFoundError:
            oa_producer_df.to_csv('Compressed Data Set ' + str(self.__size) + '.gz_batch_ref', compression='gzip', index=False)

    def __beta_reduction(self, stats: Distribution):
        return self.__z_2(stats.rvs(size=self.__size, samples=self.__monte_carlo, dtype=self.__dtype))

    def __ozturk_function(self, t: tf.Tensor):
        # Ideal, This will be just the last point
        internal_u = math.cos(self.__theta) * tf.abs(t)
        internal_v = math.sin(self.__theta) * tf.abs(t)
        temp_u = [[0] * self.__monte_carlo]
        temp_v = [[0] * self.__monte_carlo]
        for i in range(1, self.__size + 1):
            temp_u.append(raw_ops.Sum(input=internal_u[:, :i], axis=1, name='u') / i)
            temp_v.append(raw_ops.Sum(input=internal_v[:, :i], axis=1, name='v') / i)
        temp_u = np.asarray(temp_u).T
        temp_v = np.asarray(temp_v).T
        return temp_u, temp_v

    def __reference_set(self, reference_distribution='Normal'):
        """
        This finds the angles for the library
        """
        cwd = self.__change_cwd()
        ref_dict = {'Normal': norm, 'Uniform': uniform, 'Exponential': expon, 'Cauchy': cauchy, 'Laplace': laplace, 'Logistic': logistic, 'Rayleigh': rayleigh}
        try:
            reference_df = pd.read_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', dtype=self.__dtype)
            self.__theta = tf.convert_to_tensor(reference_df[reference_distribution], dtype=self.__dtype)
        except FileNotFoundError:
            reference_set = ref_dict[reference_distribution].rvs(size=self.__monte_carlo * self.__size).reshape((self.__size, self.__monte_carlo))
            reference_set.sort(axis=0)
            m = reference_set.mean(axis=1)
            theta = (np.pi * ref_dict[reference_distribution].cdf(m)).astype(self.__dtype)
            self.__theta = tf.convert_to_tensor(theta, dtype=self.__dtype, name='theta')
            reference_df = pd.DataFrame(theta, columns=[reference_distribution])
            reference_df.to_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', index=False)
        except KeyError:
            # Standardized Null Hypothesis
            reference_set = ref_dict[reference_distribution].rvs(size=self.__monte_carlo * self.__size).reshape((self.__size, self.__monte_carlo))
            reference_set.sort(axis=0)
            m = reference_set.mean(axis=1)
            theta = (np.pi * ref_dict[reference_distribution].cdf(m)).astype(self.__dtype)
            self.__theta = tf.convert_to_tensor(theta, dtype=self.__dtype, name='theta')
            reference_df[reference_distribution] = theta
            reference_df.to_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', index=False)
        self.__revert(cwd)

    def __standard_deviation(self, sample):
        return tf.sqrt(raw_ops.Sum(tf.square(sample - raw_ops.Mean(sample, 0, True) / (self.__size - 1))))
        # sample_var is the approximate sampling_standard_deviation

    def __z_2(self, p: tf.Tensor):
        """
        The Formula for Z^2
        Z**2 = (p-mu).T  *  sigma**-1  * (p-mu)
        """
        if self.__dim == 1:
            return p

        p_mean = raw_ops.Mean(input=p, axis=1, keep_dims=True)
        p_cov = tfp.stats.covariance(p, sample_axis=1, event_axis=-1, name='p_cov')
        inv_cov_numpy = np.linalg.inv(p_cov.numpy())
        inv_cov = tf.linalg.inv(p_cov, name='inv_cov')
        inv_p_cov = linalg.pinv(p_cov, name='inv_p_cov')
        p_ = math.subtract(p, p_mean, 'p_new',)
        p_t = math.conj(p_, name='p_conjugate')
        print(p_.shape)
        print(p_t.shape)
        z_2_set = []
        for i in range(self.__size):
            p_t_i = tf.reshape(p_t[:, i, :], (self.__monte_carlo, 1, self.__dim))
            p_i = tf.reshape(p_[:, i, :], (self.__monte_carlo, 1, self.__dim))
            part_one = linalg.matmul(p_t_i, inv_p_cov)
            z_2_set.append(tf.reshape(linalg.matmul(part_one, p_i, transpose_b=True), (self.__monte_carlo, 1)))
        x = tf.reshape(tf.stack(values=z_2_set, axis=1), (self.__monte_carlo, self.__size), name='z_2')
        print(x.shape)
        assert False
        return x

    def size(self):
        return self.__size

    def dim(self):
        return self.__dim

    def __adjust_columns(self, df):
        columns = list(df.columns)
        new_order = ['U', 'V']
        if 'U0' in columns:
            for i in range(self.__size + 1):
                new_order.append('U' + str(i))
                new_order.append('V' + str(i))
        stats = list(filter(lambda x: 'U' not in x, columns))
        distribution_sets = list(filter(lambda x: ' ' in x, stats))
        distributions = list(filter(lambda x: ' ' not in x, stats))
        for dist in distribution_sets:
            new_order.append(dist)
        for dist in distributions:
            new_order.append(dist)

        return df.reindex(columns=new_order)

    def __change_cwd(self):
        cwd = os.getcwd()
        os.chdir('..\\Data\\')
        cwd_dir = os.getcwd()
        new_dir = '\\dim ' + str(self.__dim)
        try:
            os.chdir(cwd_dir + new_dir)
        except FileNotFoundError:
            os.mkdir(cwd_dir + new_dir)
            os.chdir(cwd_dir + new_dir)
        return cwd

    def __revert(self, cwd):
        os.chdir(cwd)
        return self.__size

    def __str__(self):
        return 'Producer_Ozturk_[' + str(self.__size) + ']_[' + ','.join(self.__class_set) + ']'


def main(dimensions: range):
    assert (__name__ == "__main__"), "Method not intended to be called if this isn't the main file"
    stats_set = [norm, uniform, expon, laplace, logistic, cauchy, rayleigh]
    # sizes = [10, 25, 50, 75, 80, 100, 125, 150, 200, 500, 1000]
    # sizes = [10, 25, 50, 80, 100, 125, 150, 500, 1000]
    # sizes = [10, 25, 50]
    sizes = [75]
    # sizes = [5]
    mc = 10 ** 5
    for dim in dimensions:
        for size in sizes:
            training_run = OzturkTrain(monte_carlo=mc, size=size, dimension=dim)
            training_run.train(stats_set)


if __name__ == "__main__":
    '''
    Optimized for training size ANNOA
    '''
    main(dimensions=range(2, 3))
