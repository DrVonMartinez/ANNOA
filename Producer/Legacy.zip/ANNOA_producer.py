#  -*- coding: utf-8 -*-
"""
@author: Benjamin
The Goal is to have Ozturk's Algorithm:
    Utilize Data Mining:
        For Classification
        For Cluster Detection
        For Association Learning

"""
__spec__ = None

import os
import warnings

# Artificial Neural Network Ozturk
import numpy as np
import pandas as pd
import progressbar
from sklearn.preprocessing import scale as standardize
from Utilities.Constants import DIMENSION_SET, SIZE_SET, STATS_SET, MONTE_CARLO, REFERENCE_DICTIONARY
from Distribution.Distribution import Distribution

warnings.filterwarnings("ignore", category=FutureWarning)


class OzturkTrain:
    def __init__(self, monte_carlo=2000, size=200, dimension=1):
        """
        loss function selection following suggestions from https://medium.com/data-science-group-iitr/loss-functions-and-optimization-algorithms-demystified-bb92daff331c
        Optimizer selection following suggestions from https://algorithmia.com/blog/introduction-to-optimizers
        :param monte_carlo:
        :param size:
        :param dimension:
        """
        if __name__ == "__main__":
            print('Ozturk Algorithm',
                  'Monte Carlo: ' + str(monte_carlo),
                  "Dimension: " + str(dimension),
                  'Size: ' + str(size),
                  flush=True,
                  sep='\n')
        self.__monte_carlo = int(monte_carlo)
        self.__size = size
        self.__dim = int(dimension)
        self.__theta = np.asarray([])
        self.__columns = []
        self.__dtype = np.float32
        self.__class_set = []
        if self.__monte_carlo < 1000:
            warnings.warn('Warning! Small Number of Monte Carlo Simulations')

    def train(self, distributions):
        """
        :param distributions:
        :return:
        """
        import itertools
        for index in itertools.product(range(len(distributions)), repeat=self.__dim):
            dist = Distribution(distributions[index[0]])
            for i in range(1, len(index)):
                dist += Distribution(distributions[index[i]])
            assert dist.dimension() == self.__dim, 'Dimension mismatch. Dimension should be ' + str(self.__dim) + ' but is ' + str(dist.dimension())
            self.__class_set.append(dist)
        self.__determine_columns()
        cwd = self.__change_cwd()
        distribution_df = pd.DataFrame(dtype=self.__dtype)
        for i in progressbar.progressbar(range(len(self.__class_set)), redirect_stdout=True):
            distribution_set = self.__class_set[i]
            distribution_df = self.__oa_hidden_single(distribution_set).astype(dtype=self.__dtype).fillna(value=0)
            # distribution_df = distribution_df.append(current_df)
            # print(distribution_df.shape)
            self.__store_seq(distribution_df, distribution_set)
        self.__revert(cwd)

    def train_single_distribution(self, distribution_set: list):
        distribution_sequence = Distribution(distribution_set[0])
        for i in range(1, self.__dim):
            distribution_sequence += Distribution(distribution_set[i])
        self.__class_set = [str(distribution_sequence)]
        self.__determine_columns()
        cwd = self.__change_cwd()
        distribution_df = self.__oa_hidden_single(distribution_sequence)
        print(distribution_df.shape)
        self.__store_seq(distribution_df, distribution_sequence)
        print(distribution_df.columns)
        self.__revert(cwd)

    def __oa_hidden(self, distribution_sequence):
        reduced = self.__beta_reduction(distribution_sequence)
        train_ozturk = np.sort(reduced, axis=1)
        detrended = standardize(train_ozturk, axis=1)
        u, v = self.__ozturk_function(detrended)
        return u, v

    def __determine_columns(self):
        self.__columns += ['U', 'V']
        for i in range(self.__size + 1):
            self.__columns.append('U' + str(i))
            self.__columns.append('V' + str(i))
        distribution_set = list(map(str, self.__class_set))
        single_dist_set = []
        if self.__dim > 1:
            for dim_dist in distribution_set:
                for dist in dim_dist.split(' '):
                    if dist not in single_dist_set:
                        single_dist_set.append(dist)
        self.__columns += distribution_set + single_dist_set

    def __oa_hidden_single(self, distribution_sequence):
        oa_producer_df = pd.DataFrame(columns=self.__columns, dtype=self.__dtype)
        u, v = self.__oa_hidden(distribution_sequence)
        oa_producer_df['U'] = u[:, -1]
        oa_producer_df['V'] = v[:, -1]
        ones_column = [str(distribution_sequence)]
        if self.__dim > 1:
            ones = np.ones((self.__monte_carlo, 1))
            for dist in str(distribution_sequence).split(' '):
                if dist not in ones_column:
                    ones_column.append(dist)
        else:
            ones = np.ones(self.__monte_carlo)
        for values in ones_column:
            oa_producer_df[values] = ones

        for i in range(self.__size + 1):
            oa_producer_df['U' + str(i)] = u[:, i]
            oa_producer_df['V' + str(i)] = v[:, i]
        return oa_producer_df

    def __store_seq(self, oa_producer_df, distribution_sequence):
        oa_producer_df.to_csv('Compressed ' + str(distribution_sequence) + ' Data Set ' + str(self.__size) + '.gz_dist_' + str(self.__size), compression='gzip', index=False)

    def __beta_reduction(self, stats: Distribution):
        try:
            return self.__z_2(stats.rvs(size=self.__size, samples=self.__monte_carlo, dtype=self.__dtype))
        except RuntimeWarning:
            print(str(stats))
            assert False

    def __ozturk_function(self, t):
        initial_u = np.abs(t) * np.cos(self.__theta)
        initial_v = np.abs(t) * np.sin(self.__theta)
        u = np.zeros((self.__monte_carlo, self.__size + 1))
        v = np.zeros((self.__monte_carlo, self.__size + 1))
        for i in range(1, self.__size + 1):
            u[:, i] = np.sum(initial_u[:, :i], axis=1) / i
            v[:, i] = np.sum(initial_v[:, :i], axis=1) / i
        return u, v

    def reference_set(self, reference_distribution='Normal'):
        """
        This finds the angles for the library
        """
        cwd = self.__change_cwd()

        try:
            reference_df = pd.read_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', dtype=self.__dtype)
            self.__theta = reference_df[reference_distribution].to_numpy().reshape((1, self.__size))
        except FileNotFoundError:
            reference_set = REFERENCE_DICTIONARY[reference_distribution].rvs(size=self.__monte_carlo * self.__size).reshape((self.__size, self.__monte_carlo))
            reference_set.sort(axis=0)
            m = reference_set.mean(axis=1)
            self.__theta = (np.pi * REFERENCE_DICTIONARY[reference_distribution].cdf(m)).astype(self.__dtype).reshape((1, self.__size))
            reference_df = pd.DataFrame(self.__theta.reshape((self.__size, 1)), columns=[reference_distribution], index=range(self.__size))
            reference_df.to_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', index=False)
        except KeyError:
            # Standardized Null Hypothesis
            reference_df = pd.read_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', dtype=self.__dtype)
            reference_set = REFERENCE_DICTIONARY[reference_distribution].rvs(size=self.__monte_carlo * self.__size).reshape((self.__size, self.__monte_carlo))
            reference_set.sort(axis=0)
            m = reference_set.mean(axis=1)
            self.__theta = (np.pi * REFERENCE_DICTIONARY[reference_distribution].cdf(m)).astype(self.__dtype).reshape((1, self.__size))
            reference_df[reference_distribution] = self.__theta
            reference_df.to_csv('Reference Set ' + str(self.__size) + '.gz_ref', compression='gzip', index=False)
        self.__revert(cwd)

    def __z_2(self, p):
        """
        The Formula for Z^2
        Z**2 = (p-mu).T  *  sigma**-1  * (p-mu)
        """
        if self.__dim == 1:
            return p.reshape(self.__monte_carlo, self.__size)
        p_mean = p.mean(axis=1).reshape((self.__monte_carlo, 1, self.__dim))
        p_cov = np.array([np.cov(p[i, :, :], rowvar=False) for i in range(self.__monte_carlo)])
        inv_p_cov = np.linalg.inv(p_cov)
        try:
            assert not np.isnan(inv_p_cov).any()
        except AssertionError:
            inv_p_cov = np.linalg.pinv(p_cov)

        p_t = np.subtract(p, p_mean).conj()
        p_new = np.transpose(np.subtract(p, p_mean), axes=(0, 2, 1))
        z_2 = np.zeros((self.__monte_carlo, self.__size))
        for i in range(self.__size):
            p_t_temp = np.reshape(p_t[:, i, :], (self.__monte_carlo, 1, self.__dim))
            p_new_temp = np.reshape(p_new[:, :, i], (self.__monte_carlo, self.__dim, 1))
            z_2[:, i] = (p_t_temp @ inv_p_cov @ p_new_temp).reshape(self.__monte_carlo)
        return z_2

    def size(self):
        return self.__size

    def dim(self):
        return self.__dim

    def __adjust_columns(self, df):
        columns = list(df.columns)
        new_order = ['U', 'V']
        if 'U0' in columns:
            for i in range(self.__size + 1):
                new_order.append('U' + str(i))
                new_order.append('V' + str(i))
        stats = list(filter(lambda x: 'U' not in x, columns))
        distribution_sets = list(filter(lambda x: ' ' in x, stats))
        distributions = list(filter(lambda x: ' ' not in x, stats))
        for dist in distribution_sets:
            new_order.append(dist)
        for dist in distributions:
            new_order.append(dist)

        return df.reindex(columns=new_order)

    def __change_cwd(self):
        cwd = os.getcwd()
        os.chdir('..\\Data\\')
        cwd_dir = os.getcwd()
        new_dir = '\\dim ' + str(self.__dim)
        try:
            os.chdir(cwd_dir + new_dir)
        except FileNotFoundError:
            os.mkdir(cwd_dir + new_dir)
            os.chdir(cwd_dir + new_dir)
        return cwd

    def __revert(self, cwd):
        os.chdir(cwd)
        return self.__size

    def __str__(self):
        return 'gen_Ozturk_[' + str(self.__size) + ']_[' + ','.join(self.__class_set) + ']'


def main():
    assert (__name__ == "__main__"), "Method not intended to be called if this isn't the main file"
    # sizes = [10, 25, 50, 75, 80, 100, 125, 150, 200, 500, 1000]
    sizes = [10, 25, 50, 200]
    sizes = [75, 80, 100]
    sizes = [125, 150]
    # sizes = [500, 1000]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for dim in DIMENSION_SET[:1]:
            for size in SIZE_SET:
                training_run = OzturkTrain(monte_carlo=MONTE_CARLO, size=size, dimension=dim)
                training_run.reference_set()
                training_run.train(STATS_SET)


if __name__ == "__main__":
    '''
    Optimized for training size ANNOA
    '''
    main()
